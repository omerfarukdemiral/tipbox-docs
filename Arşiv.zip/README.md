# TipDocs

TipDocs, dijital içerik oluşturucular ve kullanıcılar için tasarlanmış bir dokümantasyon platformudur.

## Özellikler

- Modern ve kullanıcı dostu arayüz
- Duyarlı (responsive) tasarım
- Web2 ve Web3 entegrasyonu
- Güvenli oturum açma sistemi

## Kurulum

1. Projeyi klonlayın
2. Gerekli bağımlılıkları yükleyin
3. Tarayıcınızda `index.html` dosyasını açın

## Katkıda Bulunma

Projeye katkıda bulunmak için lütfen bir Pull Request açın.

## Lisans

Bu proje MIT lisansı altında lisanslanmıştır. 