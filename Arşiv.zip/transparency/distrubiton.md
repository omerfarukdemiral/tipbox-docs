Ecosystem (40%)

This fund rewards users for their activity on Tipbox through automated, smart contract-based distributions to drive community growth and engagement.

Unlocked Supply  
0.00%

Circulating Supply  
0.00%

Circulating Amount  
0.00%

View Addresses   
*(To be Determined)*

⸻

Investors (16%)

This fund is allocated to early investors across Private (Angel), Pre-Seed, Seed A, and Seed B rounds, supporting Tipbox’s initial development, scaling, and market entry.

Unlocked Supply  
0.00%

Circulating Supply  
0.00%

Circulating Amount  
0.00%

View Addresses   
*(To be Determined)*

⸻

Team & Resources (44%)

This fund covers the founding team’s portion, marketing efforts, operational expansion, product development, liquidity provisioning, and strategic opportunities to strengthen the platform’s long-term success.

Unlocked Supply  
0.00%

Circulating Supply  
0.00%

Circulating Amount  
0.00%

View Addresses   
*(To be Determined)*  
